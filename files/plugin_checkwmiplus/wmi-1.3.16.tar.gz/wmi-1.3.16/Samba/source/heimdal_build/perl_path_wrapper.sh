#!/bin/sh
#

SELF=$0
DIR=`dirname $SELF`

$PERL $DIR/$@
